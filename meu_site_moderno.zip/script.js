const botoes = document.querySelectorAll(".service-btn");
const content = document.getElementById("content");

const paginas = {
  inicio: `
    <section class="welcome">
      <div class="welcome-text">
        <span class="tag">PAINEL PRINCIPAL</span>
        <h1>Olá, <span>Usuário</span>!</h1>
        <p>
          Selecione um serviço no menu ao lado para acessar
          o conteúdo correspondente.
        </p>
      </div>

      <div class="welcome-card">
        <div class="card-icon">→</div>
        <strong>Escolha um serviço</strong>
        <span>O conteúdo aparecerá nesta área.</span>
      </div>
    </section>
  `,

  servico1: `
    <section class="service-page">
      <span class="tag">SERVIÇO 01</span>
      <h1>Serviço 1</h1>
      <p>
        Esta é a área reservada para o primeiro serviço.
        O sistema pode carregar aqui uma página, formulário,
        painel ou outra aplicação.
      </p>

      <div class="service-box">
        <h3>Conteúdo do serviço</h3>
        <p>Substitua este espaço pelo sistema que deseja abrir.</p>
      </div>
    </section>
  `,

  servico2: `
    <section class="service-page">
      <span class="tag">SERVIÇO 02</span>
      <h1>Serviço 2</h1>
      <p>
        O segundo serviço será exibido dentro da mesma área
        principal, mantendo a estrutura do site.
      </p>

      <div class="service-box">
        <h3>Área do Serviço 2</h3>
        <p>Aqui poderá entrar o conteúdo real do seu projeto.</p>
      </div>
    </section>
  `,

  servico3: `
    <section class="service-page">
      <span class="tag">SERVIÇO 03</span>
      <h1>Serviço 3</h1>
      <p>
        O terceiro serviço também utiliza a área principal
        sem alterar o menu lateral ou o cabeçalho.
      </p>

      <div class="service-box">
        <h3>Área do Serviço 3</h3>
        <p>Você pode colocar outra página ou sistema aqui.</p>
      </div>
    </section>
  `
};

botoes.forEach(botao => {
  botao.addEventListener("click", () => {
    botoes.forEach(b => b.classList.remove("active"));
    botao.classList.add("active");

    const pagina = botao.dataset.page;
    content.innerHTML = paginas[pagina];
  });
});
